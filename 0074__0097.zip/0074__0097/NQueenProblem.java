package practice;

import java.util.Scanner;

/*The N Queen is the problem of placing N chess queens on an N�N chess board 
 * so that no two queens attack each other.*/

public class NQueenProblem {

	//Main Tester Method
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Row Or Column Length for N x N Chess Board :");
		int N = sc.nextInt();
		
		//creating 2D array of boolean type
		boolean[][] board = new boolean[N][N];
		
		//initialize array with false.
		for(int i=0;i<N;i++)
			for(int j=0;j<N;j++)
				board[i][j] = false;
		
		//call queen with boolean 2D array and 0th Row
		System.out.println("=========== All Possible Solutions =============");
		queen(board,0);
	}
	
	static void queen(boolean[][] board,int row)
	{
		//when queens at all the rows is placed successfully then call display method and return.
		if(row == board.length) {
			display(board);
			return;
		}
		
		//placing the queen & check for each column in a row
		for(int col=0;col<board.length;col++)
		{
			//Checking whether the queen is safe to place by calling isSafe.
			if(isSafe(board,row,col))
			{
				//if queen is safe to place then make that square true
				board[row][col] = true;
				//recursively call queen method for next row
				queen(board,row+1);
				//if recursive call returns it means we cannot put queen at that position
				//so mark that position as false i.e there is no queen placed at that position
				board[row][col] = false;
			}
		}
	}
	
	//method for checking whether queen is safe to place 
	static boolean isSafe(boolean[][] board,int row,int col)
	{
		//check vertical row
		for(int i=0;i<row;i++) {
			if(board[i][col])
				return false;
		}
		
		//check for left diagonal
		int maxLeft = Math.min(row, col);
		for(int i=1;i<=maxLeft;i++) {
			if(board[row-i][col-i])
				return false;
		}
		
		//check for right diagonal
		int maxRight = Math.min(row, board.length-col-1);
		for(int i=1;i<=maxRight;i++) {
			if(board[row-i][col+i])
				return false;
		}
		
		return true;
	}
	
	//Method to display the solution
	static void display(boolean[][] board)
	{
		for(boolean[] row : board)
		{
			for(boolean i : row)
			{
				if(i == true)
					System.out.print(" Q");
				else
					System.out.print(" x");
			}
			System.out.println();
		}
		System.out.println();

	}
}
