package utils.LinkedList;

public class SList {
	SListNode head;
	SListNode tail;

	public SList() {
		head = null;
		tail = null;
	}

	public void insertAtEnd(int element) {
		// Make space for new element, newNode.
		SListNode newNode;
		newNode = new SListNode(element);

		// Store element in newNode's data
		//newNode.data = element;
		// Set newNode's next to empty
		//newNode.next = null;

		// if (list is empty) then
		if (head == null) {
			// Set head and tail to newNode
			head = newNode;
			tail = newNode;
			// Stop
			return;
		}

		// Set tail's next to newNode
		tail.next = newNode;
		// Set tail to newNode
		tail = newNode;
	}
	
	public int deleteFirst() throws Exception
	{
		if(head == null)
		{
			throw new Exception("List is Empty");
		}
		SListNode temp = head;
		if(head == tail)
		{
			head = tail = null;
			return temp.data;
		}
		head = head.next;
		return temp.data;
	}
	
	public int getCount() {
		int count = 0;
		SListNode current;

		current = head;
		while (current != null) {
			++count;
			current = current.next;
		}

		return count;
	}
	
	public boolean IsEmpty()
	{
		if(head == null)
			return true;
		return false;
	}

	public int[] getElements() {
		int elements[] = new int[getCount()];
		int i = 0;
		SListNode current;

		current = head;
		while (current != null) {
			elements[i] = current.data;
			++i;
			current = current.next;
		}
		return elements;
	}
}
