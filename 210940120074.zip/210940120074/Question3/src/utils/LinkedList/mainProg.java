package utils.LinkedList;
import java.util.Arrays;

public class mainProg {
	public static void main(String[] args) {
		SList l1 = new SList();

		try {
			l1.insertAtEnd(5);
			l1.insertAtEnd(10);
			l1.insertAtEnd(15);
			l1.insertAtEnd(20);
			l1.insertAtEnd(25);
			l1.insertAtEnd(30);
			l1.insertAtEnd(35);
			
			l1.deleteFirst();
			l1.deleteFirst();
			l1.deleteFirst();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println(Arrays.toString(l1.getElements()));
	}

}
