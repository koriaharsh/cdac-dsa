import java.util.Stack;

public class BinaryTreeOddLevelTraveral {

	BTNode root;
	
	public BinaryTreeOddLevelTraveral()
	{
		this.root = null; 
	}
	public void OddLevelTraversal()
	{
		if(root == null)
			return;
		
		//set level to one
		int level = 1;
		
		Stack<BTNode> s1 = new Stack<>();
		Stack<BTNode> s2 = new Stack<>();
		BTNode current = null;
		
		s1.push(root);
		
		while(!s1.isEmpty() || !s2.isEmpty())
		{
			//since starting level is 1
			//but in input starting level is 0
			//therefore input level even is our odd levels
			if(level %2 != 0) // --> actual input level is even
			{
				while(!s1.isEmpty())
				{
					current = s1.pop();
					// not printing any value in case of even level
					if(current.lChild != null)
						s2.push(current.lChild);
					if(current.rChild != null)
						s2.push(current.rChild);
				}
				if(s1.isEmpty())
					level++;
			}
			
			if(level%2 == 0) // acctual input level is odd
			{
				while(!s2.isEmpty())
				{
					current = s2.pop();
					//printing tree node value for odd level
					System.out.println(current.data);
					if(current.rChild != null)
						s1.push(current.rChild);
					if(current.lChild != null)
						s1.push(current.lChild);
				}
				if(s2.isEmpty())
					level++;
			}
			
		}
	}
	
	public void createBinaryTree()
	{
		BTNode n1 = new BTNode(11);
		BTNode n2 = new BTNode(12);
		BTNode n3 = new BTNode(13);
		BTNode n4 = new BTNode(14);
		BTNode n5 = new BTNode(15);
		BTNode n6 = new BTNode(16);
		BTNode n7 = new BTNode(17);
		BTNode n8 = new BTNode(18);
		BTNode n9 = new BTNode(19);
		
		n1.lChild = n2;
		n1.rChild = n3;
		
		n2.lChild = n4;
		n2.rChild = n5;
		
		n5.lChild = n7;
		n5.rChild = n8;
		
		n3.rChild = n6;
		n6.lChild = n9;
		
		root = n1;
	}
}
