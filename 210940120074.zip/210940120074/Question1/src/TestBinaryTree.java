
public class TestBinaryTree {

	public static void main(String[] args) {
		
		BinaryTreeOddLevelTraveral bt = new BinaryTreeOddLevelTraveral();
		
		bt.createBinaryTree();

//		  tree
//	      ----
//	       11         -- level 0
//	     /   \    
//	    12     13     -- level 1 
//	  /   \      \
//	 14    15     16  -- level 2    
//	  	  /   \    / 
//	     17   18  19  -- level 3	
		
		System.out.println("Odd Level Traversal Of Binary Tree");
		bt.OddLevelTraversal();
	}

}
