

public class BTNode {

	int data;
	BTNode lChild;
	BTNode rChild;
	
	public BTNode(int data)
	{
		this.data = data;
		lChild = null;
		rChild = null;
	}
}
