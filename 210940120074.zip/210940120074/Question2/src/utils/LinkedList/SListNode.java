package utils.LinkedList;

public class SListNode {
	int data;
	SListNode next;

	public SListNode(int element) {
		data = element;
		next = null;
	}
}
