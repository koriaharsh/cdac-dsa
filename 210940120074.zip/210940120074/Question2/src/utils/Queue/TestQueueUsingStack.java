package utils.Queue;

public class TestQueueUsingStack {

	public static void main(String[] args) {
		
		QueueUsingStack queue = new QueueUsingStack();
		
		
		
		try {
			
			queue.enQueue(1);
			queue.enQueue(2);
			queue.enQueue(3);
			queue.enQueue(4);
			queue.enQueue(5);
			queue.enQueue(6);
			queue.enQueue(7);
			
			queue.deQueue();
			queue.deQueue();
			
			System.out.println("queue elements after enQueue and deQueue : ");
			queue.printQueue();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

}
