package utils.Queue;

public interface QueueIntf {
	public void enQueue(int element) throws Exception;
	public int deQueue () throws Exception;
	public boolean IsEmpty();
	public boolean IsFull();
}
