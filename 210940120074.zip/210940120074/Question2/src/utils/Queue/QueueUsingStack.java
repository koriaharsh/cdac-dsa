package utils.Queue;

import utils.Stack.StackUsingSinglyLinkedList;

public class QueueUsingStack implements QueueIntf{
	
	StackUsingSinglyLinkedList s1;
	StackUsingSinglyLinkedList s2;
	
	public QueueUsingStack()
	{
		s1 = new StackUsingSinglyLinkedList();
		s2 = new StackUsingSinglyLinkedList();
	}
	
	@Override
	public void enQueue(int element) throws Exception {
		if(s1.IsEmpty()) {
			s1.Push(element);
			return;
		}
		while(!s1.IsEmpty()) {
			s2.Push(s1.Pop());
		}
		
		s1.Push(element);
		
		while(!s2.IsEmpty()) {
			s1.Push(s2.Pop());
		}
	}

	@Override
	public int deQueue() throws Exception {
		return s1.Pop();
	}

	@Override
	public boolean IsEmpty() {
		return s1.IsEmpty();
	}

	@Override
	public boolean IsFull() {
		return false;
	}
	
	public void printQueue()
	{
		s1.print();
	}

}
