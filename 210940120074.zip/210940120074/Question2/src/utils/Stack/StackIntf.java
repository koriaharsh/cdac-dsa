package utils.Stack;

public interface StackIntf {
	public void Push(int element) throws Exception;
	public int Pop() throws Exception;
	public boolean IsEmpty();
	public boolean IsFull();
}
