package utils.Stack;

import utils.LinkedList.SList;

public class StackUsingSinglyLinkedList implements StackIntf{
	
	SList list;
	
	public StackUsingSinglyLinkedList()
	{
		list = new SList();
	}
	@Override
	public void Push(int element) {
		list.AddAtFront(element);
	}

	@Override
	public int Pop() throws Exception {
		return list.DeleteFirstNode();
	}

	@Override
	public boolean IsEmpty() {
		return list.IsEmpty();
	}

	@Override
	public boolean IsFull() {
		return false;
	}
	
	public void print()
	{
		for(int i : list.getElements())
			System.out.print("-> "+i);
	}

}
