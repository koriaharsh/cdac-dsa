Solution of question no 3 is in utils.Queue(QueueUsingStack)

LinkedList and Stack are supporting classes